<?php
/**
 * @package WordPress
 * @subpackage Seeko
 * @author SeventhQueen <themesupport@seventhqueen.com>
 * @since Seeko 1.0
 */

/*
You can add here your extra SEEKO php code
*/
